#ifndef PARSE_TREE_NODES_H
#define PARSE_TREE_NODES_H

#include <iostream>
#include <vector>
#include <string>
#include "lexer.h"
#include <map>

using namespace std;
extern map<string, int> symbolTable;

// forward declarations of classes and functions
class programNode;
class Block_Node;
class Compound_Node;
class Assignment_Node;
class Expression_Node;
class Simple_Expression_Node;
class Term_Node;
class Factor_Node;
class If_Node;
class Write_Node;
class Read_Node;
class While_Node;
class Statement_Node;
class Factor_Integer;
class Factor_Float;
class Factor_Identifier;
class Nested_Expression;
class Nested_Factor;

// returns a string that represents the integer token value
// i.e. passing in 3000 will result in " + " being returned
//
// this will be useful when printing out the math and 
//   logical operators
//
string token_to_string(int token) {
    switch(token){
        case TOK_PLUS:
            return " + ";       
        case TOK_MINUS:
            return " - ";
        case TOK_MULTIPLY:
            return " * ";
        case TOK_DIVIDE:
            return " / ";
        case TOK_ASSIGN:
            return " := ";
        case TOK_EQUALTO:
            return " = ";
        case TOK_LESSTHAN:
            return " < ";
        case TOK_GREATERTHAN:
            return " > ";
        case TOK_NOTEQUALTO:
            return " <> ";
        case TOK_MOD:
            return " MOD ";
        case TOK_NOT:
            return " NOT ";
        case TOK_OR:
            return " OR ";
        case TOK_AND:
            return " AND ";
        default:
            return " UNKNOWN TOKEN ";
    }
}

//Statement_Node class
class Statement_Node
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual int interpret()
    {
        return 1;
    }

    //Destructor
    virtual ~Statement_Node(){};
};

ostream& operator<<(ostream& os, Statement_Node& node)
{
    node.printTo(os);
    return os;
}

//Parent Factor_Node class
class Factor_Node
{
public:
    virtual void printTo(ostream &os) = 0;
    virtual int interpret()
    {
        return 1;
    }
    //Destructor
    virtual ~Factor_Node(){};

};

ostream& operator<<(ostream& os, Factor_Node& node)
{
    node.printTo(os);
    return os;
}


class Factor_Integer : public Factor_Node
{
public:
    int integer_literal;

    int interpret()
    {
        return integer_literal;
    }

    //printTo method
    void printTo(ostream& os)
    {
        os << "factor( " << integer_literal << " )";
    }

    //Constructor
    Factor_Integer(int int_lit)
    {
        integer_literal = int_lit;
    }

    //Destructor
    ~Factor_Integer()
    {
        cout << "Deleting a factorNode" <<endl;
        integer_literal = 0;
    }
};

class Factor_Float : public Factor_Node
{
public:
    float floating_literal;

    int interpret()
    {
        return 1;
    }

    //printTo method
    void printTo(ostream& os)
    {   
        os << "factor( ";
        os << floating_literal;
        os << " )";
    
    }

    //Constructor
    Factor_Float(float float_lit)
    {
        floating_literal = float_lit;
    }

    //Destructor
    ~Factor_Float()
    {
        cout << "Deleting a factorNode" <<endl;
        floating_literal = 0;
    }
};

class Factor_Identifier : public Factor_Node
{
public:
    string* factor_identifier = nullptr;

    int interpret()
    {
        map<string, int>::iterator it;
        it = symbolTable.find(*factor_identifier);
        return  it->second;
    }

    //printTo method
    void printTo(ostream& os)
    {
        os << "factor( " << *factor_identifier << " )";
    }

    //Constructor
    Factor_Identifier(string factor_ident)
    {
        factor_identifier = new string(factor_ident);
    }

    //Destructor
    ~Factor_Identifier()
    {
        cout << "Deleting a factorNode" <<endl;
        delete(factor_identifier);
        factor_identifier = nullptr;  
    }
};

//Term_Node class
class Term_Node
{
public:
    Factor_Node* factor = nullptr;
    vector<Factor_Node*> factor_pointers;
    vector<int> tokens;

    int interpret()
    {
        int temp_term_1 = factor->interpret();
        int temp_term_2;
        int return_value = temp_term_1;

        if(temp_term_2)
        {
            for(int j = 0; j < tokens.size(); ++j)
            {
                temp_term_2 = factor_pointers[j]->interpret();
                switch(tokens[j])
                {
                    case TOK_MULTIPLY:
                        return_value = return_value * temp_term_2;
                        break;
                    case TOK_DIVIDE:
                        return_value = return_value / temp_term_2;
                        break;
                    case TOK_AND:
                        return_value = return_value && temp_term_2;
                        break;
                    default:
                        break; 
                }
            }
        }
        return return_value;
    }

    //Constructor
    Term_Node(Factor_Node* factor_node, vector<Factor_Node*> factors, vector <int> tok)
    {
        factor = factor_node;
        factor_pointers = factors;
        tokens = tok;
    }
    //Destructor
    ~Term_Node()
    {
        cout << "Deleting a termNode" <<endl;
	    delete(factor);
        factor = nullptr;
        for (int i = 0; i < factor_pointers.size(); ++i)
        {
		    delete(factor_pointers[i]);
		    factor_pointers[i] = nullptr;
            tokens[i] = 0;
	    }
        factor_pointers.clear();
        tokens.clear();
    }
};

ostream& operator<<(ostream& os, Term_Node& node)
{
    os << "term( ";
    if(node.factor)
        os << *(node.factor);
	for (int i = 0; i < node.factor_pointers.size(); i++)
    {
        if(node.factor_pointers.at(i))
        {
        os << token_to_string(node.tokens.at(i));
        os << *(node.factor_pointers.at(i));
        }
    }
    os << " )";
    return os;
}

//Simple_Expression_Node class
class Simple_Expression_Node
{
public:
    Term_Node* term = nullptr;
    vector<Term_Node*> term_pointers;
    vector<int> tokens;

    int interpret()
    {
        int temp_simple_expression_1 = term->interpret();
        int temp_simple_expression_2;
        int return_value = temp_simple_expression_1;

        if(temp_simple_expression_2)
        {

            for(int j = 0; j < tokens.size(); ++j)
            {
                temp_simple_expression_2 = term_pointers[j]->interpret();
                switch(tokens[j])
                {
                    case TOK_PLUS:
                        return_value = return_value + temp_simple_expression_2;
                        break;
                    case TOK_MINUS:
                        return_value = return_value - temp_simple_expression_2;
                        break;
                    case TOK_OR:
                        return_value = return_value || temp_simple_expression_2;
                        break;
                    default:
                        break; 
                }
            }
        }
        return return_value;
    }

    //Constructor
    Simple_Expression_Node(Term_Node* term_node, vector<Term_Node*> terms, vector<int> tok)
    {
        term = term_node;
        term_pointers = terms;
        tokens = tok;
    }
    //Destructor
    ~Simple_Expression_Node()
    {
        cout << "Deleting a simpleExpressionNode" <<endl;
	    delete(term);
        term = nullptr;
        for (int i = 0; i < term_pointers.size(); ++i) //deletes the 
        {
		    delete(term_pointers[i]);
		    term_pointers[i] = nullptr;
            tokens[i] = 0;
	    }
        term_pointers.clear();
        tokens.clear();
    }

};

ostream& operator<<(ostream& os, Simple_Expression_Node& node)
{
    os << "simple_expression( ";
    if(node.term)
        os << *(node.term);

	for (int i = 0; i < node.term_pointers.size(); i++)
    {
        if(node.term_pointers.at(i))
        {
        os << token_to_string(node.tokens.at(i));
        os << *(node.term_pointers.at(i));
        }
    }
    os << " )";

    return os;
}

//Expression_Node class
class Expression_Node
{
public:
    Simple_Expression_Node* expression_1 = nullptr;
    Simple_Expression_Node* expression_2 = nullptr;
    int token;

    int interpret()
    {
        int temp_expression_1 = expression_1->interpret();
        int temp_expression_2;
        int return_value = temp_expression_1;        
        if(expression_2)
        {
            temp_expression_2 = expression_2->interpret();

            switch(token)
            {
                case TOK_EQUALTO:
                    return_value = return_value == temp_expression_2;
                    break;
                case TOK_LESSTHAN:
                    return_value = return_value < temp_expression_2;
                    break;
                case TOK_GREATERTHAN:
                    return_value = return_value > temp_expression_2;
                    break;        
                case TOK_NOTEQUALTO:
                    return_value = return_value != temp_expression_2;
                    break;
                default:
                    break;
            }
        }

        return return_value;
    }

    //Constructor
    Expression_Node(Simple_Expression_Node* expr_1, Simple_Expression_Node* expr_2, int tok)
    {
        expression_1 = expr_1;
        expression_2 = expr_2;
        token = tok;

    }
    //Destructor
    ~Expression_Node()
    {
        cout << "Deleting an expressionNode" <<endl;
        delete(expression_1);
        expression_1 = nullptr;
        delete(expression_2);
        expression_2 = nullptr;
    }
};

ostream& operator<<(ostream& os, Expression_Node& node)
{
    os << "expression( ";

    if(node.expression_1)
        os << *(node.expression_1);
        
    if(node.expression_2)
        os << token_to_string(node.token) << *(node.expression_2); // <<endl;

    os << " )";

    return os;
}

//Nested_Expression class
class Nested_Expression : public Factor_Node {
public:
    Expression_Node* expression_pointer = nullptr;
    int token;

    int interpret()
    {
        return expression_pointer->interpret();
    }

    void printTo(ostream& os)
    {
        os << "nested_expression( " <<*expression_pointer << " )";
    }
    Nested_Expression(Expression_Node* expr_ptr)
    {
        expression_pointer = expr_ptr;
    }

    ~Nested_Expression()
    {
   	cout << "Deleting a factorNode" << endl;
	delete(expression_pointer);
	expression_pointer = nullptr;
    }
};

//Nested_Factor class
class Nested_Factor : public Factor_Node
{
public:
    string* op = nullptr;
    Factor_Node* factor_pointer = nullptr;

    int interpret()
    {
        if(*op == "TOK_NOT")
        {
            return !(factor_pointer->interpret());
        }
        if(*op == "TOK_MINUS")
        {
            return (0 - factor_pointer->interpret());
        }
        return 1;
    }

    void printTo(ostream& os)
    {
        os << "factor(" << *op << *(factor_pointer) << " )";
    }

    Nested_Factor(int operator_arg, Factor_Node* fac_ptr)
    {
        op = new string(token_to_string(operator_arg));
        factor_pointer = fac_ptr;
    }

    ~Nested_Factor()
    {
        cout << "Deleting a factorNode" << endl;
        delete(op);
        op = nullptr;
        delete(factor_pointer);
        factor_pointer = nullptr;
    }

};

//Write_Node class
class Write_Node : public Statement_Node
{
public:
    string* write_identifier = nullptr;
    int token;

    int interpret()
    {
        if(token == TOK_IDENT)
        {
            map<string, int>::iterator it;
            it = symbolTable.find(*write_identifier);
            cout << it->second <<endl;
            return 1;
        }
        if(token == TOK_STRINGLIT)
        {
            string temp_string = write_identifier->substr(1,write_identifier->size()-2);
            cout << temp_string << endl;
            return 1;
        }
        return 1;
    }

    //printTo method
    void printTo(ostream& os)
    {
        if(write_identifier)
        {
            if(token == TOK_IDENT)
            {
                os << "Write Value " << *write_identifier;
            }
            if(token == TOK_STRINGLIT)
            {
                os << "Write String " << *write_identifier;
            }
        }
    }

    //Constructor
    Write_Node(string str, int temp_token)
    {
        write_identifier = new string(str);
        token = temp_token;
    }
    
    //Destructor
    ~Write_Node()
    {
        cout << "Deleting a writeNode" <<endl;
        delete(write_identifier);
        write_identifier = nullptr;
    }

};

//Read_Node class
class Read_Node : public Statement_Node
{
public:
    string* read_identifier = nullptr;

    int interpret()
    {
        map<string, int>::iterator it;
        it = symbolTable.find(*read_identifier);
        cin >> it->second;
        return 1;
    }

    //printTo method
    void printTo(ostream& os)
    {
        os << "Read " << *(read_identifier);
    }

    //Constructor
    Read_Node(string name)
    {
        read_identifier = new string(name);
    }

    //Destructor
    ~Read_Node()
    {
        cout << "Deleting a readNode" <<endl;
        delete(read_identifier);
        read_identifier = nullptr;
    }
};

//While_Node class
class While_Node : public Statement_Node
{
public:
    Expression_Node* while_expression = nullptr;
    Statement_Node* while_body = nullptr;
    
    int interpret()
    {
        while(while_expression->interpret() == true)
        {
            while_body->interpret();
        }
        return 1;
    }

    //printTo method
    void printTo(ostream& os)
    {
        os << "While " << *while_expression <<endl;
        os << "%%%%%%%% Loop Body %%%%%%%%" <<endl;
        os << *while_body;
        os << "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%";
    }

    //Constructor
    While_Node(){}

    //Destructor
    ~While_Node()
    {
        cout << "Deleting a whileNode" <<endl;  
        delete(while_expression);
        while_expression = nullptr;
        delete(while_body);
        while_body = nullptr;
    }

};

//If_Node Class
class If_Node : public Statement_Node
{
public:
    Expression_Node* expression = nullptr;
    Statement_Node* then_state = nullptr;
    Statement_Node* else_state = nullptr;

    int interpret()
    {
        int if_state = expression->interpret();

        if(else_state)
        {
            if(if_state != 0)
                return then_state->interpret();
            else
                return else_state->interpret();
        }
        else
        {
            if(if_state != 0)
                return then_state->interpret();
        }
        return 1; 
    }

    //printTo method
    void printTo(ostream& os)
    {
        os << "If " << *(expression) <<endl;
        os << "%%%%%%%% True Statement %%%%%%%%" <<endl;
        os << *then_state;
        os << "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";

        if(else_state != nullptr)
        {
            os << "\n%%%%%%%% False Statement %%%%%%%%" <<endl;
            os << *else_state;
            os << "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";
        }
    }

    //Constructor
    If_Node() {}
    //Destructor
    ~If_Node()
    {
        cout << "Deleting an ifNode" <<endl;
        delete(expression);
        expression = nullptr;
        delete(then_state);
        then_state = nullptr;
        delete(else_state);
        else_state = nullptr;
    }
};

//Assignment_Node class
class Assignment_Node : public Statement_Node
{
public:
    string* identifier = nullptr;
    Expression_Node* expression = nullptr;

    int interpret()
    {
        map<string, int>::iterator it;  // temporary iterator for symbolTable
        //allows access to index of symbolTable to find the identifer
        it = symbolTable.find(*identifier);
        //sets the second value of the iterator to the return of
        //"expression"'s value to the interpret function in Expression_Node
        it->second = expression->interpret();
        return 1;
    }

    void printTo(ostream& os)
    {
        os << "Assignment " << *identifier << " := ";
        if(expression)
            os << *expression;
    }
    //Constructor
    Assignment_Node(string ident1, Expression_Node* expr)
    {
        identifier = new string(ident1);
        expression = expr;
    }

    //Destructor
    ~Assignment_Node()
    {
        cout << "Deleting an assignmentNode" << endl;
        delete(identifier);
        identifier = nullptr;
        delete(expression);
        expression = nullptr;
    }
};

//Compound_Node
class Compound_Node : public Statement_Node
{

public:
    vector<Statement_Node*> statements;

    int interpret()
    {
        for(int i = 0; i < statements.size(); ++i)
        {
            statements[i]->interpret();
        }
        return 1;
    }    

    void printTo(ostream& os)
    {
        os << "Begin Compound Statement" << endl;
        for(int i = 0; i < statements.size(); ++i)
        {
            if(statements[i])
                os << *(statements[i]) << endl;
        }
        os << "End Compound Statement";
    }

    Compound_Node()
    {

    }

    ~Compound_Node()
    {
        cout << "Deleting a compoundNode" << endl;
        int length = statements.size();
        for(int i = 0; i < length; ++i)
        {
            delete statements[i];
            statements[i] = nullptr;
        }
    };

};

//Block_Node class
class Block_Node
{
public:
    Compound_Node* compound = nullptr;

    int interpret()
    {
        return compound->interpret();
    }

    //Constructor
    Block_Node(Compound_Node* comp)
    { 
        compound = comp;
    }

    //Destructor
    ~Block_Node()
    {
        cout << "Deleting a blockNode" << endl;
        delete(compound);
        compound = nullptr;
    }

};

ostream& operator<<(ostream& os, Block_Node& node)
{
    os << *(node.compound) << endl;
    return os;
}

class programNode
{
public:
    string* name = nullptr;
    Block_Node* block = nullptr;

    int interpret()
    {
        return block->interpret();
    }

    //Constructor
    programNode(string id, Block_Node* blk)
    {
        name = new string(id);
        block = blk;
    }

    //Destructor
    ~programNode()
    {
        cout << "Deleting a programNode" << endl;
        delete(name);
        name = nullptr;
        delete(block);
        block = nullptr;
    }
};

// example of << for a parse tree node (no inheritance is involved)
ostream& operator<<(ostream& os, programNode& node)
{
    os << "Program Name " << *(node.name) << endl;
    if(node.block)
        os << *(node.block) <<endl;

    return os;
}

#endif