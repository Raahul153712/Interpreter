/**********************************************************
 * Name: Raahul Pathak                      NetID: rcp250 *
 * Course: CSE-4714 Programming Languages                 *
 * Purpose: The purpose of this part of the project was   *
 * to build the parse tree while we check the syntax of   *
 * the input.                                             *
 **********************************************************/

#ifndef PRODUCTIONS_H
#define PRODUCTIONS_H

#include "lexer.h"
#include "parse_tree_nodes.h"
#include <iostream>
#include <set>
#include <map>

// extern set<string> symbolTable;
extern map<string, int> symbolTable;
int nextToken = 0;  // token returned from yylex
int level = 0;  // used to indent output to approximate parse tree


extern "C"
{
	// Instantiate global variables used by flex
	extern char* yytext;       // text of current lexeme
	extern int   yylex();      // the generated lexical analyzer
}


// Forward declarations for Part 3 pointer functions
programNode* program();
Block_Node* block_grammar();
Compound_Node* compound_grammar();
Statement_Node* statement_grammar();
Assignment_Node* assignment_grammar();
If_Node* if_grammar();
While_Node* while_grammar();
Read_Node* read_grammar();
Write_Node* write_grammar();
Expression_Node* expression_grammar();
Simple_Expression_Node* simple_expression_grammar();
Term_Node* term_grammar();
Factor_Node* factor_grammar();

// Forward declarations of functions that check
// whether the current token is in the first set 
// of a production rule
bool first_token_of_program();
bool first_token_of_block();
bool first_token_of_compound();
bool first_token_of_statement();
bool first_token_of_assignment();
bool first_token_of_if();
bool first_token_of_while();
bool first_token_of_read();
bool first_token_of_write();
bool first_token_of_expression();
bool first_token_of_simple_expression();
bool first_token_of_term();
bool first_token_of_factor();


inline void indent()
{
    for (int i = 0; i<level; i++)
        cout << ("    ");
}

void output()
{
    indent();
    cout << "-->found " << yytext << endl;
}

int lex()
{
  nextToken = yylex();
  if (nextToken == TOK_EOF)
  {
      yytext[0] = 'E';
      yytext[1] = 'O';
      yytext[2] = 'F';
      yytext[3] = 0;
  }

//   printf("Next token: %d, Next lexeme is %s\n", nextToken, yytext);
  return nextToken;
}


//programNode pointer function
programNode* program()
{
    //Check if the <prog> starts with a valid token
    if(!first_token_of_program())
        throw "3: 'PROGRAM' expected";
    
    indent();
    cout << "enter <program>" << endl;
    ++level;
    programNode* new_programNode = nullptr;

    if(nextToken == TOK_PROGRAM)
    {
        output();
        lex();
    }
    else
        throw "3: 'PROGRAM' expected";

    string name = yytext;

    if(nextToken == TOK_IDENT)
    {
        output();
        lex();
    }
    else
        throw "2: identifier expected";
        
    if(nextToken == TOK_SEMICOLON)
    {
        output();
        lex();
        new_programNode = new programNode(name, block_grammar());
    }
    else
        throw "14: ';' expected";
    --level;
    indent();
    cout << "exit <program>" << endl;

return new_programNode;
}

//bool function for first_token_of_program
bool first_token_of_program(void)
{
    return nextToken == TOK_PROGRAM;
}

//Block_Node pointer function
Block_Node* block_grammar()
{
    if (!first_token_of_block()) // Check for VAR OR begin
        throw "18: error in declaration part OR 17: 'BEGIN' expected";
    
    indent();
    cout << "enter <block>" << endl;
    ++level;
    Block_Node* new_Block_Node = new Block_Node(nullptr);
    if (nextToken == TOK_VAR)
    {
        output();
        lex();
    }

    while(nextToken)
    {
        if(nextToken != TOK_IDENT)
        {
            break;
        }
        if (nextToken == TOK_IDENT) 
        {
            if(symbolTable.count(yytext) > 0)
            {
                throw "101: identifier declared twice";
            }
            symbolTable.insert({yytext, 0});
            output();
            lex();
        }
        else
            throw "2: identifier expected";
        
        if (nextToken == TOK_COLON)
        {
            output();
            lex();
        }
        else
            throw "5: ':' expected";

        if((nextToken == TOK_INTEGER) || (nextToken == TOK_REAL))
        {
            output();
            lex();
        }
        else
            throw "10: error in type";

        if(nextToken == TOK_SEMICOLON)
        {
            output();
            lex();
        }
        else
            throw "14: ';' expected";
        
        cout<<endl;
    }

    new_Block_Node->compound = compound_grammar();

    --level;
    indent();
    cout << "exit <block>" << endl;

    return new_Block_Node;
}


//bool function for first_token_of_block
bool first_token_of_block()
{
    return nextToken == TOK_VAR || nextToken == TOK_BEGIN;
}

//Compound_Node pointer function
Compound_Node* compound_grammar()
{

    if(!first_token_of_compound())
    {
        throw "17: 'BEGIN' expected";
    }
    
    indent();
    cout << "enter <compound_statement>"<< endl;
    ++level;

    Compound_Node* new_Compound_Node = new Compound_Node;
    output();
    lex();

    new_Compound_Node->statements.push_back(statement_grammar());

    if(nextToken == TOK_BEGIN)
    {
        output();
        lex();

        new_Compound_Node->statements.push_back(statement_grammar());

    }

    while (nextToken == TOK_SEMICOLON)
    {
        output();
        lex();
        new_Compound_Node->statements.push_back(statement_grammar());
    }

    if(nextToken == TOK_END)
    {
        output();
        lex();
    }

    --level;
    indent();
    cout << "exit <compound_statement>"<< endl;

    return new_Compound_Node;
}

//bool function for first_token_of_compound
bool first_token_of_compound()
{
    return nextToken == TOK_BEGIN;
}

//Statement_Node pointer function                //Not done, more function calls needed
Statement_Node* statement_grammar()
{
    
    if (!first_token_of_statement())
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <statement>" << endl;
    ++level;
    Statement_Node* new_Statement_Node = nullptr;


    switch (nextToken)
    {
        case TOK_IDENT:
            new_Statement_Node = assignment_grammar();
            break;
        case TOK_BEGIN:
            new_Statement_Node = compound_grammar();
            break;
        case TOK_IF:
            new_Statement_Node = if_grammar();
            break;
        case TOK_WHILE:
            new_Statement_Node = while_grammar();
            break;
        case TOK_READ:
            new_Statement_Node = read_grammar();
            break;
        case TOK_WRITE:
            new_Statement_Node = write_grammar();
            break;
        default:
                throw "999: an error has occured"; 
    
    }

    if((nextToken == TOK_IDENT) || (nextToken == TOK_BEGIN) || 
     (nextToken == TOK_IF) || (nextToken == TOK_WHILE) ||
        (nextToken == TOK_READ) || (nextToken == TOK_WRITE))
    {
        new_Statement_Node = statement_grammar();
    }

    --level;
    indent();
    cout << "exit <statement>" << endl;   

    return new_Statement_Node;

}


//bool function for first_token_of_statement
bool first_token_of_statement()
{
    return nextToken == TOK_IDENT || nextToken == TOK_BEGIN ||
    nextToken == TOK_IF || nextToken == TOK_WHILE || nextToken == TOK_READ ||
    nextToken == TOK_WRITE;
}

//Assignment_Node pointer function
Assignment_Node* assignment_grammar()
{
    if (!first_token_of_assignment())
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <assignment>" << endl;
    ++level;
    Assignment_Node* new_Assignment_Node = nullptr;
    Expression_Node* new_Expression_Node = nullptr;
    string text;
    
    if(nextToken == TOK_IDENT)
    {
        if(symbolTable.count(yytext) == 0)
        {
            throw "104: identifier not declared";
        }
        output();
        text = yytext;
        lex();
    }

    else
        throw "2: identifier expected";

    if(nextToken == TOK_ASSIGN)
    {
        output();
        lex();
    }
    else
        throw "51: ':=' expected";
    
    new_Expression_Node = expression_grammar();
    new_Assignment_Node = new Assignment_Node(text, new_Expression_Node);
    
    --level;
    indent();
    cout << "exit <assignment>" << endl;

    return new_Assignment_Node;

}


//bool function for first_token_of_assignment
bool first_token_of_assignment()
{
    return nextToken == TOK_IDENT;
}


//If_Node pointer function
If_Node* if_grammar()
{
    if (!first_token_of_if()) // Check for PROGRAM
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <if statement>" << endl;
    ++level;
    If_Node* if_block = new If_Node();


    if(nextToken == TOK_IF)
    {
        output();
        lex();
    }
    
    if_block->expression = expression_grammar();

    if(nextToken == TOK_THEN)
    {
        output();
        lex();
    }
    else
        throw "52: 'THEN' expected";

    if_block->then_state = statement_grammar();

    if(nextToken == TOK_ELSE)
    {
        output();
        lex();
        if_block->else_state = statement_grammar();
    }

    --level;
    indent();
    cout << "exit <if statement>" << endl;

    return if_block;

}


//bool function for first_token_of_if
bool first_token_of_if()
{
    return nextToken == TOK_IF;
}

//While_Node pointer function
While_Node* while_grammar()
{
    if (!first_token_of_while()) // Check for PROGRAM
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <while statement>" << endl;
    ++level;
    While_Node* while_loop = new While_Node();

    if(nextToken == TOK_WHILE)
    {
        output();
        lex();
    }

    while_loop->while_expression = expression_grammar();
    while_loop->while_body = statement_grammar();

    --level;
    indent();
    cout << "exit <while statement>" << endl;

    return while_loop;
}


//bool function for first_token_of_while
bool first_token_of_while()                
{
    return nextToken == TOK_WHILE;
}

//Read_Node pointer function
Read_Node* read_grammar()
{
   string temp_string; 
    if (!first_token_of_read())
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <read>" << endl;
    ++level;
    Read_Node* new_Read_Node = nullptr;

    if(nextToken == TOK_READ)
    {
        output();
        lex();
    }
    else
        throw "900: illegal type of statement";
    
    if(nextToken == TOK_OPENPAREN)
    {
        output();
        lex();
    }
    else
        throw "9: '(' expected";

    if(nextToken == TOK_IDENT)
    {
        if(symbolTable.count(yytext) == 0)
        {
            throw "104: identifier not declared";
        }
        temp_string = yytext;
        output();
        lex();
    }
    else
        throw "2: identifier expected";

    if(nextToken == TOK_CLOSEPAREN)
    {
        output();
        lex();
    }
    else
        throw "4: ')' expected";
    
    --level;
    indent();
    cout << "exit <read>" << endl;
    
    new_Read_Node = new Read_Node(temp_string);    

    return new_Read_Node;

}

//bool function for first_token_of_read
bool first_token_of_read()
{
    return nextToken == TOK_READ;
}

//Write_Node pointer function
Write_Node* write_grammar()
{
    if (!first_token_of_write())
        throw "900: illegal type of statement";
    
    indent();
    cout << "enter <write>" << endl;
    ++level;

    Write_Node* new_Write_Node = nullptr;
    string passed_string;
    int temp_token;

    if(nextToken == TOK_WRITE)
    {
        output();
        lex();
    }

    if(nextToken == TOK_OPENPAREN)
    {
        output();
        lex();
    }
    else
        throw "9: '(' expected";

    if((nextToken == TOK_IDENT) || nextToken == TOK_STRINGLIT)
    {
        if(nextToken == TOK_IDENT)
        {
            if(symbolTable.count(yytext) == 0)
            {
                throw "104: identifier not declared";
            }
            passed_string = yytext;
            temp_token = nextToken;
            
        }
        else if(nextToken == TOK_STRINGLIT)
        {
            passed_string = yytext;
            temp_token = nextToken;     
        }
        output();
        lex();
    }
    else
        throw "134: illegal type of operand(s)";

    if(nextToken == TOK_CLOSEPAREN)
    {
        output();
        lex();
    }
    else
        throw "4: ')' expected";

   --level;
    indent();
    cout << "exit <write>" << endl;

    new_Write_Node = new Write_Node(passed_string, temp_token);
    return new_Write_Node;

}


//bool function for first_token_of_write
bool first_token_of_write()
{
    return nextToken == TOK_WRITE;
}

//Expression_Node pointer function
Expression_Node* expression_grammar()
{
    if (!first_token_of_expression())
        throw "144: illegal type of expression";
    
    indent();
    cout << "enter <expression>" << endl;
    ++level;
    
    Expression_Node* new_Expression_Node = nullptr;
    Simple_Expression_Node* new_Simple_Expression_Node_1 = nullptr;
    Simple_Expression_Node* new_Simple_Expression_Node_2 = nullptr;
    int token;
    
    new_Simple_Expression_Node_1 = simple_expression_grammar();

    if(((nextToken == TOK_EQUALTO) || (nextToken == TOK_LESSTHAN) || (nextToken == TOK_GREATERTHAN)
    || (nextToken == TOK_NOTEQUALTO)))
    {
        token = nextToken;
        output();
        lex();
        new_Simple_Expression_Node_2 = simple_expression_grammar();
    }

    --level;
    indent();
    cout << "exit <expression>" << endl;

    new_Expression_Node = new Expression_Node(new_Simple_Expression_Node_1, new_Simple_Expression_Node_2, token);

    return new_Expression_Node;
}


//bool function for first_token_of_expression
bool first_token_of_expression()
{
    return nextToken == TOK_INTLIT ||
    nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT ||
    nextToken == TOK_OPENPAREN || nextToken == TOK_NOT ||
    nextToken == TOK_MINUS;
}

//Simple_Expression_Node pointer function
Simple_Expression_Node* simple_expression_grammar()
{

    if (!first_token_of_simple_expression())
        throw "901: illegal type of simple expression";
    
    indent();
    cout << "enter <simple expression>" << endl;
    ++level;
    
    Simple_Expression_Node* new_Simple_Expression_Node = nullptr;
    Term_Node* new_Term_Node_1 = nullptr;
    vector<Term_Node*> loop_terms;
    vector<int> tokens;

    new_Term_Node_1 = term_grammar();

    while(nextToken)
    {
        if((nextToken == TOK_PLUS) || (nextToken == TOK_MINUS)
        || (nextToken == TOK_OR))
        {
            tokens.push_back(nextToken);

            output();
            lex();
            loop_terms.push_back(term_grammar());
        }

        if((nextToken != TOK_PLUS) && (nextToken != TOK_MINUS)
        && (nextToken != TOK_OR))
        {
            break;
        }   
    }
    new_Simple_Expression_Node = new Simple_Expression_Node(new_Term_Node_1, loop_terms, tokens);

    --level;
    indent();
    cout << "exit <simple expression>" << endl;

    return new_Simple_Expression_Node;

}


//bool function for first_token_of_simple_expression
bool first_token_of_simple_expression()
{
    return nextToken == TOK_INTLIT ||
    nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT ||
    nextToken == TOK_OPENPAREN || nextToken == TOK_NOT ||
    nextToken == TOK_MINUS;
}

//Term_Node pointer function
Term_Node* term_grammar()
{
    if (!first_token_of_term()) // Check for PROGRAM
        throw "902: illegal type of term";
    
    indent();
    cout << "enter <term>" << endl;
    ++level;
    
    Term_Node* new_Term_Node = nullptr;
    Factor_Node* new_Factor_Node_1 = nullptr;
    vector<Factor_Node*> loop_factors;
    vector<int> tokens;

    new_Factor_Node_1 = factor_grammar();

    while (nextToken)
    {
        if((nextToken == TOK_MULTIPLY) || (nextToken == TOK_DIVIDE)
        || (nextToken == TOK_AND))
        {
            tokens.push_back(nextToken);
            output();
            lex();
            loop_factors.push_back(factor_grammar());
        }

        if((nextToken != TOK_MULTIPLY) && (nextToken != TOK_DIVIDE)
        && (nextToken != TOK_AND))
        {
            break;
        }
    }
    
    new_Term_Node = new Term_Node(new_Factor_Node_1, loop_factors, tokens);

    --level;
    indent();
    cout << "exit <term>" << endl;

    return new_Term_Node;
}


//bool function for term
bool first_token_of_term()
{
    return nextToken == TOK_INTLIT ||
    nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT ||
    nextToken == TOK_OPENPAREN || nextToken == TOK_NOT ||
    nextToken == TOK_MINUS;
}

//Factor_Node pointer function
Factor_Node* factor_grammar()
{
    if (!first_token_of_factor())
        throw "903: illegal type of factor";
    
    indent();
    cout << "enter <factor>" << endl;
    ++level;
    Factor_Node* factor_pointer = nullptr;
    int token;


    switch(nextToken)
    {
        case TOK_INTLIT:
            factor_pointer = new Factor_Integer(atoi(yytext));
            output();
            lex();
            break;
        case TOK_FLOATLIT:
            factor_pointer = new Factor_Float(atof(yytext));
            output();
            lex();
            break;
        case TOK_IDENT:
            if(symbolTable.count(yytext) == 0)
            {
                throw "104: identifier not declared";
            }
            factor_pointer = new Factor_Identifier(yytext);
            output();
            lex();
            break;
        case TOK_OPENPAREN:
            output();
            lex();
            factor_pointer = new Nested_Expression(expression_grammar());
            if(nextToken == TOK_CLOSEPAREN)
            {
                output();
                lex();
            }
            else
                throw "4: ')' expected";
            break;
        case TOK_NOT:
            token = nextToken;
            output();
            lex();
            factor_pointer = new Nested_Factor(token, factor_grammar());
            break;
        case TOK_MINUS:
            token = nextToken;
            output();
            lex();
            factor_pointer = new Nested_Factor(token, factor_grammar());
            break;
        default:
            throw "999: an error has occured";
    }

    --level;
    indent();
    cout << "exit <factor>" << endl;

    return factor_pointer;

}

// bool function for factor
bool first_token_of_factor()
{
    return nextToken == TOK_INTLIT ||
    nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT ||
    nextToken == TOK_OPENPAREN || nextToken == TOK_NOT ||
    nextToken == TOK_MINUS;
}

#endif